SELECT DISTINCT
	Field14 as ApiVersion
INTO 
	'Reports/%FilePrefix%_ApiVersion.tsv'
FROM 
	'Reports/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE 
	Field13 <> null
	and Field13 <> 'nomadVersion'
	and Field14 <> null