SELECT 
	AVG(TO_REAL(Field2)) as CPU
INTO 	
	'Reports/%FilePrefix%.CPU.tsv'
FROM 
	'Reports\performance.%FromDate%_%ToDate%.log'
WHERE
	Field2 <> 'processorTime'