SELECT
    TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Bytes='), 0, ',')) as Bytes,
    TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ',')) as Duration
INTO '%ReportsPath%/%FilePrefix%_ConvertationBytesDurationReport.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
    Field3 like '<- DocumentExport%' AND 
    Field6 like '%format=pdf%'