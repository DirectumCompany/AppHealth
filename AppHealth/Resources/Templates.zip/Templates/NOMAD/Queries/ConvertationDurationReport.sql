SELECT
    EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Extension='), 0, ',') as Extension,  
	Count(1) as Hits,
    MAX(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ','))) as DurationMax,
	AVG(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ','))) as DurationAVG,
	MAX(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Bytes='), 0, ','))) as SizeMAX,
	AVG(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Bytes='), 0, ','))) as SizeAVG	
INTO '%ReportsPath%/%FilePrefix%_ConvertationExtensionReport.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
    Field3 like '<- DocumentExport%' AND 
    Field6 like '%format=pdf%'
GROUP BY Extension

--2017-01-05 13:02:00.280 +04:00	Info 	<- DocumentExport, Duration=, Host=192.168.17.4, Id=8575243, HttpMethod=GET, Bytes=88820, Content-Encoding:None  	galinsky_rs ru-RU	192.168.17.4	/DocumentExport.ashx?id=8575243&nosign=true&format=pdf	
--Bytes=88820