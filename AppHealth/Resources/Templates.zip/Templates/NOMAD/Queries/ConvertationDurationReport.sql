SELECT
    EXTRACT_TOKEN(EXTRACT_TOKEN(Field4, 1, 'Extension='), 0, ' ') as Extension,  
	Count(1) as Hits,
    MAX(TO_INT(Field5)) as DurationMax,
	AVG(TO_INT(Field5)) as DurationAVG,
	MAX(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field4, 1, 'Bytes='), 0, ' '))) as SizeMAX,
	AVG(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field4, 1, 'Bytes='), 0, ' '))) as SizeAVG	
INTO '%ReportsPath%/%FilePrefix%_ConvertationExtensionReport.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
    Field3 like '<- DocumentExport%' AND 
    Field4 like '%format=pdf%'
GROUP BY Extension
