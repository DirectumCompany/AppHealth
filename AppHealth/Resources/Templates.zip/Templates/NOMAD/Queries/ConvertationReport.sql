SELECT
    EXTRACT_TOKEN(EXTRACT_TOKEN(Field4, 1, 'Extension='), 0, ' ') as Extension, 
    TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field4, 1, 'Bytes='), 0, ' ')) as Bytes,
    TO_INT(Field5) as Duration
INTO 
	'%ReportsPath%/%FilePrefix%_ConvertationExtensionBytesDurationReport.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
    Field3 like '<- DocumentExport%' AND 
    Field4 like '%format=pdf%'