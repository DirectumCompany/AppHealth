SELECT 
	SUM(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Bytes='), 0, ','))) AS BytesSUM, 
	AVG(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Bytes='), 0, ','))) AS BytesAVG
INTO 
	'%ReportsPath%/%FilePrefix%_DocumentBytes.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '<- DocumentExport%Bytes=%' AND Field3 NOT like '%Bytes=0,%'

