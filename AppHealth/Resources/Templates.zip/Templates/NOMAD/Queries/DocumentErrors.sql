SELECT 
	STRCAT('<b>', STRCAT(Field6, '</b>: ')) AS HttpCode, 
	Count(*) AS Hits
INTO 
	'%ReportsPath%/%FilePrefix%_DocumentErrors.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '<- DocumentExport%' AND Field6 <> '200'
GROUP BY
	Field6
ORDER BY
	HttpCode
