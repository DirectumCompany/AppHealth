SELECT 
	STRCAT('<b>', STRCAT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'HttpCode='), 0, ','), '</b>: ')) AS HttpCode, 
	Count(*) AS Hits
INTO 
	'%ReportsPath%/%FilePrefix%_DocumentErrors.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '<- DocumentExport%HttpCode=%' AND Field3 NOT like '%HttpCode=200%'
GROUP BY
	EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'HttpCode='), 0, ',')
ORDER BY
	HttpCode
