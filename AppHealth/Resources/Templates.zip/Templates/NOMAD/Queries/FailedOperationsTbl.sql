SELECT TOP 20 DISTINCT EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, ' '), 0, ',') as Operation, TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Code='), 0, ',')) as Code, Extract_filename(EXTRACT_TOKEN(Field4, 0, ' ')) as Login, count(Operation) as Hit
INTO 'Reports/%FilePrefix%_FailedOperations.tsv'
-- ���� � ��������������� �����
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE 
	Field3 like '<-%' AND (Field3 like '%Code=%') AND Field6 like '%.asmx'
	AND NOT ((Field3 like '%Code=0%') OR (Field3 like '%Code=d12%') OR (Field3 like '%Code=511%') OR (Field3 like '%Code=101%') OR (Field3 like '%Code=721%') OR (Field3 like '%Code=921%'))
GROUP BY Operation, Code, Login
ORDER BY Hit DESC
