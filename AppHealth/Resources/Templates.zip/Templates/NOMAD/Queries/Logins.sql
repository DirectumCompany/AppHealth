SELECT 
	DISTINCT Extract_filename(EXTRACT_TOKEN(Field4, 0, ' ')) as Login

INTO 
	'%ReportsPath%/%FilePrefix%_Logins.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '<-%'	
ORDER BY 
	Login	
