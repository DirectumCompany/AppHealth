SELECT 
	Field1 as Time,  
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, '<-'), 0, ', ')) as Operation, 
	TO_LOWERCASE(TRIM(Extract_filename(EXTRACT_TOKEN(Field4, 0, ' ')))) as Login, 
	EXTRACT_TOKEN(EXTRACT_TOKEN(Field9, 1, 'RequestNumber='), 0, ', ') as Request,
	Field8 as UserAgent,
	
	TO_LOWERCASE(TRIM(EXTRACT_TOKEN(Field4, -1, ' '))) as Language, 	
	
	
	--Nomad=2.5.0.20133, WebAccess.API=5.4.0.1031
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field10, 1, 'Nomad='), 0, ', ')) as NomadVersion,
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field10, 1, 'WebAccess.API='), 0, ', ')) as APIVersion,
	
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Code='), 0, ', ')) as Code,
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ', ')) as Duration,
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Bytes='), 0, ', ')) as Bytes,
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Count='), 0, ', ')) as Count,	 	
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Extension='), 0, ', ')) as Extension,
	TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Format='), 0, ', ')) as Format,
	
	'NPO Computer' as Organization
	--Field3 as Message
INTO 
	'%ReportsPath%/%FilePrefix%_LogstashReady.log'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
    Field3 like '<-%'