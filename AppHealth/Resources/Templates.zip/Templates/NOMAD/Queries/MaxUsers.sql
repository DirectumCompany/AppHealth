SELECT 
	MAX(Field4) as CPU
INTO 
	'Reports/%FilePrefix%.MaxUsers.tsv'
FROM 
	'Reports\performance.%FromDate%_%ToDate%.log'
WHERE 
	Field1 <> 'time'