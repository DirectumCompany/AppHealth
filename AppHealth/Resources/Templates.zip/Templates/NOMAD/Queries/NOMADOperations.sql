SELECT DISTINCT 
	EXTRACT_TOKEN(Field3, 1, '-') as Operation, 
	count(Operation) as Hit, 
	MAX(TO_INT(Field5)) as PerformanceMax, 
	AVG(TO_INT(Field5)) as PerformanceAVG
INTO 
	'%ReportsPath%/%FilePrefix%_Operations.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE 
	Field3 like '<-%'
GROUP BY 
	Operation 
ORDER BY 
	Hit DESC