SELECT DISTINCT EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, '-'), 0, ',') as Operation, count(Operation) as Hit, MAX(TO_INT(TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ',')))) as PerformanceMax, AVG(TO_INT(TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ',')))) as PerformanceAVG
INTO '%ReportsPath%/%FilePrefix%_Operations.tsv'
-- ���� � ��������������� �����
FROM '%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE 
	Field3 like '<-%'
GROUP BY Operation 
ORDER BY Hit DESC
--<- UpdateScope, Duration=, Lag=3,9027, Count=3410  	shergina_tp ru-RU