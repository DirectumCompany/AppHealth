SELECT DISTINCT
	Field13 as Version
INTO 
	'Reports/%FilePrefix%_Version.tsv'
FROM 
	'Reports/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE 
	Field13 <> null
	and Field13 <> 'nomadVersion'
	and Field14 <> null