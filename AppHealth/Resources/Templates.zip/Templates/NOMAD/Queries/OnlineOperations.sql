SELECT 	sum( 
			CASE EXTRACT_TOKEN(Field3, 0, ' ') 
			WHEN '->' THEN 1
			ELSE 0 END
			) As Income, 
			
		sum( 
			CASE EXTRACT_TOKEN(Field3, 0, ' ')
			WHEN '<-' THEN 1
			ELSE 0 END
			) As Outcome
			
INTO 
	'%ReportsPath%/%FilePrefix%_OnlineOperations.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE 
	Field2 = 'Info' 
	AND Field10 like '%.asmx'
	AND (Field3 like '-> %' OR Field3 like '<- %')
	