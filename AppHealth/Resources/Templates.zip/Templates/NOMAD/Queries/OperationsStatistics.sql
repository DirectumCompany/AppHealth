SELECT 
	Count(1) as Total, 
	SUM(SuccessCode) as Success, 
	SUM(FailedCode) as Failed, 
	SUM(RepeatCode) as Repeated, 
	SUM(RepeatCodeNew) as RepeatNew
USING 
  CASE strcnt(Field6, '0') WHEN 1 THEN 1 ELSE 0 END AS SuccessCode, 
  CASE strcnt(Field6, '0') WHEN 0 THEN 1 ELSE 0 END AS FailedCode,
  CASE strcnt(Field6, '511') WHEN 1 THEN 1 ELSE 0 END AS RepeatCode,
  CASE strcnt(Field6, 'd12') WHEN 1 THEN 1 ELSE 0 END AS RepeatCodeNew
  
INTO 
	'Reports/%FilePrefix%_OperationsStat.tsv'
FROM 
	'Reports/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE 
	Field6 <> null and Field6 <> 'code' and Field3 like '<-'
