SELECT 
	count(*)
INTO 
	'%ReportsPath%/%FilePrefix%_PDFDocumentRequests.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '-> DocumentExport' and Field4 like '%Format=pdf%'	

