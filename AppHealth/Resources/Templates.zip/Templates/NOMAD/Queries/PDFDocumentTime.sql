SELECT 
	AVG(TO_INT(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ','))) AS ConvertTimeAVG
INTO 
	'%ReportsPath%/%FilePrefix%_PDFDocumentTime.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '<- DocumentExport%Extension=PDF%'	AND NOT Field3 like '%Bytes=0%'