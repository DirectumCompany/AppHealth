SELECT 
	AVG(TO_INT(Field5)) AS ConvertTimeAVG
INTO 
	'%ReportsPath%/%FilePrefix%_PDFDocumentTime.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '<- DocumentExport%' and Field4 like 'Extension=PDF%' AND NOT Field4 like '%Bytes=0%'