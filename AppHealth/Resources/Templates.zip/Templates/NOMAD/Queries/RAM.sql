SELECT 
	MAX(Field3)  as MAXRAM
INTO 
	'Reports/%FilePrefix%.RAM.tsv'
FROM 
	'Reports\performance.%FromDate%_%ToDate%.log'
WHERE
	Field3 <> 'privateWorkingSet' 