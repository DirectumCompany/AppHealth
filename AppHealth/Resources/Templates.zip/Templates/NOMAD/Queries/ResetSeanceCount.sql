SELECT count(*) as Restart
INTO 
	'%ReportsPath%/%FilePrefix%_ResetSeanceCount.tsv'
FROM 
	'Reports/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like 'Данные сеанса пользователя были сброшены%' AND Field3 like '%Ошибка взаимодействия%'
