SELECT 
	count(*) as Restart
INTO 
	'%ReportsPath%/%FilePrefix%_RestartCount.tsv'
FROM 
	'Reports/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like 'Процесс запуска сервера NOMAD завершен%' OR Field3 like 'NOMAD Server start-up process has been completed%'
