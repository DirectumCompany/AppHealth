SELECT 
	COUNT(*) AS Hits 
INTO 
	'%ReportsPath%/%FilePrefix%_UniqueErrors.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_TopErrors.tsv'
