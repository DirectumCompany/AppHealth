SELECT count(Login) as Users
INTO 
	'%ReportsPath%/%FilePrefix%_UniqueUsersCount.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Logins.tsv'
WHERE
	Login <> 'unknown'
