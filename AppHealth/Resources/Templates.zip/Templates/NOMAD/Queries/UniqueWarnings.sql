SELECT 
	COUNT(*) AS Hits 
INTO 
	'%ReportsPath%/%FilePrefix%_UniqueWarnings.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_TopWarnings.tsv'
