SELECT DISTINCT 
	Extract_filename(EXTRACT_TOKEN(Field7, 0, ' ')) as Login, 
	AVG(TO_INT(Field5)) as TimeAVG, 
	AVG(TO_INT(TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field4, 1, 'count='), 0, ' ')))) as ObjectsAVG,
	count(1) as Hits
INTO 
	'%ReportsPath%/%FilePrefix%_UpdateTime.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE	
	Field3 like '%<- FillScope%'
GROUP BY  	
	Login
ORDER BY 
	TimeAVG DESC
