SELECT DISTINCT Extract_filename(EXTRACT_TOKEN(Field4, 0, ' ')) as Login, AVG(TO_INT(TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Duration='), 0, ',')))) as TimeAVG, AVG(TO_INT(TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Lag='), 0, ',')))) as DelayAVG, AVG(TO_INT(TRIM(EXTRACT_TOKEN(EXTRACT_TOKEN(Field3, 1, 'Count='), 0, ',')))) as ObjectsAVG, count(1) as Hits
INTO '%ReportsPath%/%FilePrefix%_UpdateTime.tsv'
-- ���� � ��������������� �����
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE	
	Field3 like '%<- UpdateScope%'
	GROUP BY  	
		Login
	ORDER BY 
		TimeAVG DESC

-- Info 	<- UpdateScope, Duration=, Lag=3,9027, Count=3410  	shergina_tp ru-RU					