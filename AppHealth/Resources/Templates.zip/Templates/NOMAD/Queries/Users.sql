SELECT DISTINCT
	Extract_filename(EXTRACT_TOKEN(Field7, 0, ' ')) as Login,
	CASE EXTRACT_TOKEN(Field9, 1, 'Jazz') WHEN null THEN 'Solo' ELSE 'Jazz' END As Client,
	CASE EXTRACT_TOKEN(Field9, 1, 'Android') WHEN null THEN 'iOS:' ELSE 'Android:' END As OS
INTO 
	'%ReportsPath%/%FilePrefix%_Users.tsv'
FROM 
	'%ReportsPath%/%FilePrefix%_Server_%FromDate%_%ToDate%_Log.log'
WHERE
	Field3 like '<- GetObjects%' AND Field7 <> null
GROUP BY 
	Login, 
	Client, 
	OS
ORDER BY 
	Login