SELECT DISTINCT Client, OS, count(Login) as Users
INTO '%ReportsPath%/%FilePrefix%_UsersCount.tsv'
FROM '%ReportsPath%/%FilePrefix%_Users.tsv'
GROUP BY Client, OS