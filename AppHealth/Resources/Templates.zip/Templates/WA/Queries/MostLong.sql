/*  New Query  */
SELECT TOP 5 Field9 as Operation, COALESCE(Field16, Field18) as ObjectCode, DIV(Avg(TO_REAL(Field7)),1000) as AverageTime, DIV(Max(TO_REAL(Field7)),1000) as MaxTime, DIV(Min(TO_REAL(Field7)),1000) as MinTime, Count(Operation) as RequestCount
INTO '%ReportsPath%/%FilePrefix%_MostLongOperations.tsv'
 FROM '%ReportsPath%/%FilePrefix%_%FromDate%_%ToDate%_Profiling.prf' GROUP BY Operation, ObjectCode ORDER BY AverageTime desc

--Select Field14 From 'C:\Users\akberov_ni\Desktop\TehkasLogs\npowa.tsv'

