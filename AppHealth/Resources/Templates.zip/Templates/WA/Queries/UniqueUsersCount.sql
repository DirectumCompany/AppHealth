SELECT count(distinct field5)
INTO '%ReportsPath%/%FilePrefix%_UniqueUsersCount.tsv'
FROM '%ReportsPath%/%FilePrefix%_%FromDate%_%ToDate%_Log.tsv'
WHERE	Field3 = 'WAAPI' AND Field4 = 'Verbose' AND Field5 like '%UserLogin%' and EXTRACT_TOKEN(Field5,1, 'UserLogin : ') is not null