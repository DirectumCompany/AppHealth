SELECT DISTINCT EXTRACT_TOKEN(Field6,1, ' ') 
INTO '%ReportsPath%/%FilePrefix%_UniqueWAVersion.tsv'
FROM '%ReportsPath%/%FilePrefix%_%FromDate%_%ToDate%_Log.tsv'
WHERE	Field3 = 'WAAPI' AND Field5 like '%Application initialization completed%'